import React from "react";
import "./App.css";
import Child from "./components/Child";
import FunctionalChild from "./components/FunctionalChild";
import States from "./components/States";
const App = () => {
  return (
    <div>
      <Child />
      <FunctionalChild />
      <States />
    </div>
  );
};

export default App;
