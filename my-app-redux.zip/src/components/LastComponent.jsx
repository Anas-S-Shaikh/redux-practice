import React, { Component } from "react";
import { connect } from "react-redux";
import { INC_PRODUCT, INC_USER, SET_PRODUCT, SET_USER } from "../Actions";

//function to connect with class that allows us to use states as props
//syntax : anyVar : store.reducerName.stateName
function mapStateToProps(store) {
  return {
    userCount: store.userReducer.userCount,
    userName: store.userReducer.userName,
    productCount: store.productReducer.productCount,
    productName: store.productReducer.productName,
  };
}
class LastComponent extends Component {
  //dispatch method comes as props because of "connect"
  //syntax: this.props.dispatch(action_name)
  constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);
  }
  handleChange(e) {
    const { name, value } = e.target;
    switch (name) {
      case "productName":
        this.props.dispatch(SET_PRODUCT(value));
        break;
      case "username":
        this.props.dispatch(SET_USER(value));
        break;

      default:
        break;
    }
  }
  render() {
    return (
      <div className='container lastcomp'>
        <h1>Child of Chlid Component</h1>
        <span>User Count : {this.props.userCount}</span>
        <button onClick={() => this.props.dispatch(INC_USER)}>
          increament
        </button>
        <span>Username : {this.props.userName}</span>

        <input
          type="text"
          value={this.props.userName}
          name="username"
          placeholder="username"
          onChange={this.handleChange}
        />

        <span>Product Count : {this.props.productCount}</span>
        <button onClick={() => this.props.dispatch(INC_PRODUCT)}>
          increament
        </button>
        <span>Product Name : {this.props.productName}</span>
        <input
          type="text"
          value={this.props.productName}
          name="productName"
          placeholder="productName"
          onChange={this.handleChange}
        />
      </div>
    );
  }
}
export default connect(mapStateToProps)(LastComponent);
