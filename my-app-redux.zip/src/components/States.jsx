import React, { Component } from "react";
import { connect } from "react-redux";

function mapStateToProps(store) {
  return {
    userCount: store.userReducer.userCount,
    userName: store.userReducer.userName,
    productCount: store.productReducer.productCount,
    productName: store.productReducer.productName,
  };
}
class States extends Component {
  render() {
    return (
      <div className='container'>
        <h1>All states values from store</h1>
        <p>user count :{this.props.userCount}</p>
        <p>user name :{this.props.userName}</p>
        <p>product count :{this.props.productCount}</p>
        <p>product name :{this.props.productName}</p>
      </div>
    );
  }
}
export default connect(mapStateToProps)(States);
