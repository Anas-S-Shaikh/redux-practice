import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { INC_PRODUCT, INC_USER, SET_PRODUCT, SET_USER } from "../Actions";

const FunctionalChild = () => {
  const dispatch = useDispatch();
  const { productCount, productName } = useSelector(
    (reducer) => reducer.productReducer
  );
  const { userCount, userName } = useSelector((reducer) => reducer.userReducer);

  const incProduct = () => {
    dispatch(INC_PRODUCT);
  };
  const incUser = () => {
    dispatch(INC_USER);
  };

  const handleChange = (e) => {
    switch (e.target.name) {
      case "productName":
        dispatch(SET_PRODUCT(e.target.value));
        break;
      case "username":
        dispatch(SET_USER(e.target.value));
        break;

      default:
        break;
    }
  };
  return (
    <div className='container functional'>
      <h1>Functional Component (same level)</h1>

      <span> productCount: {productCount}</span>
      <span>productName : {productName}</span>
      <button onClick={incProduct}>increament product</button>
      <input
        type="text"
        value={productName}
        name="productName"
        placeholder="productName"
        onChange={handleChange}
      />

      <span> userCount: {userCount}</span>
      <span>username : {userName}</span>
      <button onClick={incUser}>increament user</button>
      <input
        type="text"
        value={userName}
        name="username"
        placeholder="username"
        onChange={handleChange}
      />
    </div>
  );
};

export default FunctionalChild;
