import React, { Component } from "react";
import { connect } from "react-redux";
import { INC_PRODUCT, INC_USER } from "../Actions";
import LastComponent from "./LastComponent";

//function to connect with class that allows us to use states as props
//syntax : anyVar : store.reducerName.stateName
function mapStateToProps(store) {
  return {
    userCount: store.userReducer.userCount,
    productCount: store.productReducer.productCount,
  };
}
class Child extends Component {
  //dispatch method comes as props because of "connect"
  //syntax: this.props.dispatch(action_name)
  incUser = () => {
    this.props.dispatch(INC_USER);
  };
  incProduct = () => {
    this.props.dispatch(INC_PRODUCT);
  };
  // dnc = () => {
  //   this.props.dispatch(decreament);
  // };
  render() {
    return (
      <div className='container child'>
        <h1>Child Component</h1>
        <span>User Count: {this.props.userCount}</span>
        <span>Product Count: {this.props.productCount}</span>
        <button onClick={this.incUser}>increament user</button>
        <button onClick={this.incProduct}>increament product</button>
        {/* <button onClick={this.dnc}>decreament</button> */}
        <LastComponent />
      </div>
    );
  }
}

export default connect(mapStateToProps)(Child);
