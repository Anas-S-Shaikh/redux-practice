import { combineReducers } from "redux";

import userReducer from "./userReducer";
import productReducer from "./productReducer";

const rootReducer = combineReducers({userReducer,productReducer});
export default rootReducer;

// const initialState = {
//   count: 1,
// };

// function reducer(state = initialState, action) {
//   switch (action.type) {
//     case "INC":
//       return {
//         count: state.count + 1,
//       };
//     case "DNC":
//       return {
//         count: state.count - 1,
//       };

//     default:
//       return state;
//   }
// }

// export default reducer;
