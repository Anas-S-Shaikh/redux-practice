const initialState = {
  userCount: 0,
  userName: "Enter to update",
  userAge: 0,
};

function userReducer(state = initialState, { type, payload }) {
  switch (type) {
    case "INC_USER":
      return {
        ...state,
        userCount: state.userCount + 1,
      };
    case "SET_USER":
      return {
        ...state,
        userName: payload,
      };
    case "SET_AGE":
      return {
        ...state,
        userName: state.userName,
      };
    default:
      return state;
  }
}

export default userReducer;
