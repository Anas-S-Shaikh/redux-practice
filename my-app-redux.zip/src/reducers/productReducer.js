const initialState = {
  productCount: 0,
  productName: "Enter to change",
};

function productReducer(state = initialState, { type, payload }) {
  switch (type) {
    case "INC_PRODUCT":
      return {
        ...state,
        productCount: state.productCount + 1,
      };
    case "SET_PRODUCT":
      return {
        ...state,
        productName: payload,
      };
    default:
      return state;
  }
}

export default productReducer;
