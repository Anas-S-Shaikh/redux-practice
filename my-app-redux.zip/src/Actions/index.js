export const INC_USER = {
  type: "INC_USER",
};
export const SET_USER = (userName) => ({
  type: "SET_USER",
  payload: userName,
});
export const INC_PRODUCT = {
  type: "INC_PRODUCT",
};
export const SET_PRODUCT = (productName) => ({
  type: "SET_PRODUCT",
  payload: productName,
});
